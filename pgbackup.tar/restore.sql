--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE testing;
--
-- Name: testing; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE testing WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE testing OWNER TO postgres;

\connect testing

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: wallmart; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA wallmart;


ALTER SCHEMA wallmart OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cars; Type: TABLE; Schema: wallmart; Owner: postgres
--

CREATE TABLE wallmart.cars (
    brand character varying(255),
    model character varying(255),
    year integer
);


ALTER TABLE wallmart.cars OWNER TO postgres;

--
-- Name: databasechangelog; Type: TABLE; Schema: wallmart; Owner: postgres
--

CREATE TABLE wallmart.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE wallmart.databasechangelog OWNER TO postgres;

--
-- Name: databasechangeloglock; Type: TABLE; Schema: wallmart; Owner: postgres
--

CREATE TABLE wallmart.databasechangeloglock (
    id integer NOT NULL,
    locked boolean NOT NULL,
    lockgranted timestamp without time zone,
    lockedby character varying(255)
);


ALTER TABLE wallmart.databasechangeloglock OWNER TO postgres;

--
-- Name: truck; Type: TABLE; Schema: wallmart; Owner: postgres
--

CREATE TABLE wallmart.truck (
    brand character varying(255),
    model character varying(255),
    year integer
);


ALTER TABLE wallmart.truck OWNER TO postgres;

--
-- Data for Name: cars; Type: TABLE DATA; Schema: wallmart; Owner: postgres
--

COPY wallmart.cars (brand, model, year) FROM stdin;
\.
COPY wallmart.cars (brand, model, year) FROM '$$PATH$$/4847.dat';

--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: wallmart; Owner: postgres
--

COPY wallmart.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
\.
COPY wallmart.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM '$$PATH$$/4845.dat';

--
-- Data for Name: databasechangeloglock; Type: TABLE DATA; Schema: wallmart; Owner: postgres
--

COPY wallmart.databasechangeloglock (id, locked, lockgranted, lockedby) FROM stdin;
\.
COPY wallmart.databasechangeloglock (id, locked, lockgranted, lockedby) FROM '$$PATH$$/4846.dat';

--
-- Data for Name: truck; Type: TABLE DATA; Schema: wallmart; Owner: postgres
--

COPY wallmart.truck (brand, model, year) FROM stdin;
\.
COPY wallmart.truck (brand, model, year) FROM '$$PATH$$/4848.dat';

--
-- Name: databasechangeloglock databasechangeloglock_pkey; Type: CONSTRAINT; Schema: wallmart; Owner: postgres
--

ALTER TABLE ONLY wallmart.databasechangeloglock
    ADD CONSTRAINT databasechangeloglock_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

